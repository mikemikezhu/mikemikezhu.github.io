//
//  MZObject.m
//  ReferenceCycleDemo
//
//  Created by Mikemikezhu on 2/20/19.
//  Copyright © 2019 Mikemikezhu. All rights reserved.
//

#import "MZObject.h"

typedef void(^MZReferenceCycleCompletionBlock)(void);

@interface MZObject ()

@property (nonatomic, strong) MZReferenceCycleCompletionBlock referenceCycleCompletionBlock;

@property (nonatomic, strong) NSString *text;

@end

@implementation MZObject

#pragma mark - Initialize

- (instancetype)init {
	self = [super init];
	if (self) {
		NSLog(@">>>>>>>>>> Initialize");
	}
	return self;
}

#pragma mark - Dealloc

- (void)dealloc {
	NSLog(@">>>>>>>>>> Dealloc");
}

#pragma mark - Public methods

- (void)testReferenceCycle1 {

	// This will create reference cycle
	self.referenceCycleCompletionBlock = ^{
		NSLog(@">>>>>>>>>> Test reference cycle");
		self.text = @"text";
		NSLog(@">>>>>>>>>> Text: %@", self.text);
	};

	self.referenceCycleCompletionBlock();
}

- (void)testReferenceCycle2 {

	// This will NOT create reference cycle
	__weak typeof(self) weakSelf = self;
	self.referenceCycleCompletionBlock = ^{
		typeof(self) strongSelf = weakSelf;
		NSLog(@">>>>>>>>>> Test reference cycle");
		strongSelf.text = @"text";
		NSLog(@">>>>>>>>>> Text: %@", strongSelf.text);
	};

	self.referenceCycleCompletionBlock();
}

- (void)testReferenceCycle3 {

	// This will NOT create reference cycle
	__weak typeof(self) weakSelf = self;
	self.referenceCycleCompletionBlock = ^{
		dispatch_queue_t serialQueue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0);
		dispatch_async(serialQueue, ^{
			sleep(10);
			NSLog(@">>>>>>>>>> Test reference cycle");
			weakSelf.text = @"text";

			// The text will be "nil",
			// Because "self" is deallocated
			// And "weakSelf" is pointing to "nil"
			NSLog(@">>>>>>>>>> Text: %@", weakSelf.text);
		});
	};

	self.referenceCycleCompletionBlock();
}

- (void)testReferenceCycle4 {

	// This will NOT create reference cycle
	__weak typeof(self) weakSelf = self;
	self.referenceCycleCompletionBlock = ^{
		typeof(self) strongSelf = weakSelf;
		dispatch_queue_t serialQueue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0);
		dispatch_async(serialQueue, ^{
			sleep(10);
			NSLog(@">>>>>>>>>> Test reference cycle");
			strongSelf.text = @"text";
			NSLog(@">>>>>>>>>> Text: %@", strongSelf.text); // The text will NOT be "nil"
		});
	};

	self.referenceCycleCompletionBlock();
}

- (void)testReferenceCycle5 {

	// This will NOT create reference cycle
	[self performBlockWithCompletion:^{
		NSLog(@">>>>>>>>>> Test reference cycle");
		self.text = @"text";
		NSLog(@">>>>>>>>>> Text: %@", self.text);
	}];
}

- (void)testReferenceCycle6 {

	// This will NOT create reference cycle
	void (^completionBlock)(void) = ^{
		NSLog(@">>>>>>>>>> Test reference cycle");
		self.text = @"text";
		NSLog(@">>>>>>>>>> Text: %@", self.text);
	};

	[self performBlockWithCompletion:completionBlock];
}

#pragma mark - Private methods

- (void)performBlockWithCompletion:(void (^)(void))completionBlock {
	if (completionBlock) {
		completionBlock();
	}
}

@end
