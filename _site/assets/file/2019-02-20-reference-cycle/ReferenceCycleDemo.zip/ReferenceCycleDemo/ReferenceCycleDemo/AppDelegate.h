//
//  AppDelegate.h
//  ReferenceCycleDemo
//
//  Created by Mikemikezhu on 2/20/19.
//  Copyright © 2019 Mikemikezhu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

