//
//  MZViewController.m
//  ReferenceCycleDemo
//
//  Created by Mikemikezhu on 2/20/19.
//  Copyright © 2019 Mikemikezhu. All rights reserved.
//

#import "MZViewController.h"
#import "MZObject.h"

@interface MZViewController ()

@end

@implementation MZViewController

- (void)viewDidLoad {
	[super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.

	MZObject *obj = [[MZObject alloc] init];
	[obj testReferenceCycle1];
	//	[obj testReferenceCycle2];
	//	[obj testReferenceCycle3];
	//	[obj testReferenceCycle4];
	//	[obj testReferenceCycle5];
	//	[obj testReferenceCycle6];
	obj = nil;
}

@end
