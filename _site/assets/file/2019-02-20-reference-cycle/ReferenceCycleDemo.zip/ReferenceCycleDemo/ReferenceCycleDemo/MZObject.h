//
//  MZObject.h
//  ReferenceCycleDemo
//
//  Created by Mikemikezhu on 2/20/19.
//  Copyright © 2019 Mikemikezhu. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface MZObject : NSObject

- (void)testReferenceCycle1;

- (void)testReferenceCycle2;

- (void)testReferenceCycle3;

- (void)testReferenceCycle4;

- (void)testReferenceCycle5;

- (void)testReferenceCycle6;

@end

NS_ASSUME_NONNULL_END
